//List of files which are indexed.
fl = new Array();
fl["0"]= "ch01.html";
fl["1"]= "ch02.html";
fl["2"]= "ch02s01.html";
fl["3"]= "ch02s02.html";
fl["4"]= "ch02s03.html";
fl["5"]= "ch02s04.html";
fl["6"]= "ch03.html";
fl["7"]= "ch03s01.html";
fl["8"]= "ch03s02.html";
